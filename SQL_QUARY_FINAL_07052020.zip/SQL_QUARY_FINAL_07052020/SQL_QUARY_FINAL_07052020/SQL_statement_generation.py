from utils import check_get,get_comp, get_num


##
####in_statement = "count the Student whos branch is E&tc"
##
####in_statement = "count the company"
##
##in_statement = "Hello world"
##
####in_statement = "delete students whoS cgpa marks greater or equal than 8"
##
####in_statement = "list company name amdocs"
##
####in_statement = "delete company whos company name is Tata"
##
##in_statement = "delete the students whos roll number is 4300"
##
##
##in_statement = "delete th student whose status equal to placed and branch equal to mech and roll number is 8051"



def get(in_statement):

    QUARY = "Invalid input"


    and_q = 0


    ################################################################################################################################################
    ################################################################################################################################################
    ################################################################################################################################################

    if(in_statement.lower().find("list")!=-1  or  in_statement.lower().find("select")!=-1 or  in_statement.lower().find("sort")!=-1 ):
        if(in_statement.lower().find("students")!=-1  or  in_statement.lower().find("student")!=-1 ):
            QUARY = "Select * from student "
            
    ######
            if(in_statement.lower().find("roll")!=-1  or  in_statement.lower().find("roll_number")!=-1  or  in_statement.lower().find("roll_no")!=-1 ):
                if(and_q == 1):
                    QUARY = QUARY + " and roll_no " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE roll_no " + get_comp(in_statement) + get_num(in_statement)

    ######
            if(in_statement.lower().find("cgpa")!=-1  or  in_statement.lower().find("cgpa marks")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and cgpa " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE cgpa " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("diploma")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and diploma " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE diploma " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("hsc")!=-1  or  in_statement.lower().find("12th")!=-1 or  in_statement.lower().find("twelfth")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and hsc " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE hsc " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("ssc")!=-1  or  in_statement.lower().find("10th")!=-1 or  in_statement.lower().find("xth")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and ssc " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE ssc " + get_comp(in_statement) + get_num(in_statement)

            

    ######
            if(in_statement.lower().find("statu")!=-1  or  in_statement.lower().find("placed_status")!=-1 or  in_statement.lower().find("Status")!=-1 ):
                if(in_statement.lower().find("place")!=-1 or in_statement.lower().find("placed")!=-1):
                    if(and_q == 1):
                        QUARY = QUARY + " and Placed_status = 'YES' "
                    if(and_q == 0):
                        QUARY = QUARY + "WHERE Placed_status = 'YES' "
                        and_q = 1
                if(in_statement.lower().find("not_plac")!=-1 or in_statement.lower().find("not place")!=-1):
                    if(and_q == 1):
                        QUARY = QUARY + " and Placed_status = 'NO' "
                    if(and_q == 0):
                        QUARY = QUARY + "WHERE Placed_status = 'NO' "
                        and_q = 1
        

            if(in_statement.lower().find("branch")!=-1  or  in_statement.lower().find("department")!=-1 or  in_statement.lower().find("stream")!=-1 ):
                if(in_statement.lower().find("computer")!=-1  or  in_statement.lower().find("comp")!=-1 ):
                    if(and_q == 1):        
                        QUARY = QUARY + " and Branch = 'COMPUTER' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'COMPUTER' "
                    
                if(in_statement.lower().find("it")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'IT' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'IT' "

                if(in_statement.lower().find("mechanical")!=-1  or  in_statement.lower().find("mech")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'Mechanical' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'Mechanical' "

                if(in_statement.lower().find("entc")!=-1  or  in_statement.lower().find("electronics")!=-1 or in_statement.lower().find("e&tc")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'E&TC' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'E&TC' "
            
                if(in_statement.lower().find("instru")!=-1  or  in_statement.lower().find("instrumentation")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'Intrumentation' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'Intrumentation' "

    ######

        elif(in_statement.lower().find("compani")!=-1  ):
            QUARY = "Select * from company "
            if(in_statement.lower().find("packag")!=-1  or  in_statement.lower().find("salari")!=-1 ):
                if(and_q==1):
                   QUARY = QUARY + " and Package " + get_comp(in_statement) + get_num(in_statement)
                if(and_q==0):
                   QUARY = QUARY + "WHERE Package " + get_comp(in_statement) + get_num(in_statement)
                   and_q=1
            
            if(in_statement.lower().find("name")!=-1 or in_statement.lower().find("companynam")!=-1 ):
                if(in_statement.lower().find("microsoft")!=-1 ):
                    if(and_q == 1):
                       QUARY = QUARY + " and company_name = 'Microsoft'"
                    if(and_q == 0):
                        QUARY = QUARY + " WHERE company_name = 'Microsoft'"
                        and_q=1
                if(in_statement.lower().find("amdoc")!=-1 ):
                    
                   if(and_q == 1):
                       QUARY = QUARY + " and company_name = 'Amdoc'"
                   if(and_q == 0):
                        QUARY = QUARY + "WHERE company_name = 'Amdoc'"
                        and_q=1
                if(in_statement.lower().find("tata")!=-1 ):    
                   if(and_q == 1):
                       QUARY = QUARY + " and company_name = 'TATA Motors'"
                   if(and_q == 0):
                        QUARY = QUARY + " WHERE company_name = 'TATA Motors'"
                        and_q=1

                if(in_statement.lower().find("city")!=-1 or in_statement.lower().find("citi corp")!=-1 ):    
                   if(and_q == 1):
                       QUARY = QUARY + " and company_name = 'Citi Corp'"
                   if(and_q == 0):
                        QUARY = QUARY + "WHERE company_name = 'Citi Corp'"
                        and_q=1

                if(in_statement.lower().find("baxter")!=-1 ):    
                   if(and_q == 1):
                       QUARY = QUARY + " and company_name = 'Baxter'"
                   if(and_q == 0):
                        QUARY = QUARY + "WHERE company_name = 'Baxter'"
                        and_q=1
                if(in_statement.lower().find("honeywell")!=-1 ):    
                   if(and_q == 1):
                       QUARY = QUARY + " and company_name = 'Honeywell'"
                   if(and_q == 0):
                        QUARY = QUARY + "WHERE company_name = 'Honeywell'"
                        and_q=1

            if(in_statement.lower().find("job rol")!=-1 or in_statement.lower().find("Job_Role")!=-1 ):
                if(in_statement.lower().find("developer")!=-1 or in_statement.lower().find("develop")!=-1 ):
                    if(and_q==1):
                      QUARY = QUARY + " and Job_role = 'Developer'"
                    if(and_q==0):
                      QUARY = QUARY + "WHERE Job_role = 'Developer'"
                      and_q=1

                if(in_statement.lower().find("software")!=-1 or in_statement.lower().find("softwar associ")!=-1 ):    
                   if(and_q==1):
                      QUARY = QUARY + " and Job_role = 'SoftwareAssociater'"
                   if(and_q==0):
                      QUARY = QUARY + "WHERE Job_role = 'SoftwareAssociater'"
                      and_q=1 

                if(in_statement.lower().find("graduate")!=-1 or in_statement.lower().find("graduat")!=-1):    
                   if(and_q==1):
                      QUARY = QUARY + " and Job_role = 'Graduate Tranee'"
                   if(and_q==0):
                      QUARY = QUARY + "WHERE Job_role = 'Graduate Tranee'"
                      and_q=1 
                if(in_statement.lower().find("research")!=-1 or in_statement.lower().find("r&d")!=-1 ):    
                   if(and_q==1):
                      QUARY = QUARY + " and Job_role = 'R&D'"
                   if(and_q==0):
                      QUARY = QUARY + "WHERE Job_role = 'R&D'"
                      and_q=1 
                if(in_statement.lower().find("tester")!=-1 ):    
                   if(and_q==1):
                      QUARY = QUARY + " and Job_role = 'Tester'"
                   if(and_q==0):
                      QUARY = QUARY + "WHERE Job_role = 'Tester'"
                      and_q=1  

                if(in_statement.lower().find("automation")!=-1 or in_statement.lower().find("autom")!=-1):    
                   if(and_q==1):
                      QUARY = QUARY + " and Job_role = 'Automation'"
                   if(and_q==0):
                      QUARY = QUARY + "WHERE Job_role = 'Automation'" 
                      and_q=1

        if(in_statement.lower().find("eligibility")!=-1  or  in_statement.lower().find("branch")!=-1 or  in_statement.lower().find("stream")!=-1 ):
                if(in_statement.lower().find("computer")!=-1  or  in_statement.lower().find("comp")!=-1 ):
                    if(and_q == 1):        
                        QUARY = QUARY + " and eligibility = 'COMP' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE eligibility = 'COMP' "
                    
                if(in_statement.lower().find("it")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and eligibility = 'IT' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE eligibility = 'IT' "

                if(in_statement.lower().find("mechanical")!=-1  or  in_statement.lower().find("mech")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and eligibility = 'Mechanical' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE eligibility = 'Mechanical' "

                if(in_statement.lower().find("entc")!=-1  or  in_statement.lower().find("electronics")!=-1 or in_statement.lower().find("e&tc")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and eligibility = 'E&TC' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE eligibility = 'E&TC' "
            
                if(in_statement.lower().find("instru")!=-1  or  in_statement.lower().find("instrumentation")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and eligibility = 'Intrumentation' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE eligibility = 'Intrumentation' "

                if(in_statement.lower().find("All")!=-1  or  in_statement.lower().find("all")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and eligibility = 'All Branch' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE eligibility = 'All Branch' "

#############
                      
        ################################################################################################################################################
    ################################################################################################################################################
    ################################################################################################################################################

    if(in_statement.lower().find("number of")!=-1  or  in_statement.lower().find("count")!=-1 ):
        if(in_statement.lower().find("students")!=-1  or  in_statement.lower().find("student")!=-1 ):
            QUARY = "SELECT COUNT * from student "
            if(in_statement.lower().find("statu")!=-1  or  in_statement.lower().find("placed_status")!=-1 or  in_statement.lower().find("Status")!=-1 ):
                if(in_statement.lower().find("place")!=-1 or in_statement.lower().find("placed")!=-1):
                    if(and_q == 1):
                        QUARY = QUARY + " and Placed_status = 'YES' "
                    if(and_q == 0):
                        QUARY = QUARY + "WHERE Placed_status = 'YES' "
                        and_q = 1
                if(in_statement.lower().find("not_plac")!=-1 or in_statement.lower().find("not place")!=-1):
                    if(and_q == 1):
                        QUARY = QUARY + " and Placed_status = 'NO' "
                    if(and_q == 0):
                        QUARY = QUARY + "WHERE Placed_status = 'NO' "
                        and_q = 1
        
    ######
            if(in_statement.lower().find("roll")!=-1  or  in_statement.lower().find("roll_number")!=-1  or  in_statement.lower().find("roll_no")!=-1 ):
                if(and_q == 1):
                    QUARY = QUARY + " and roll_no " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE roll_no " + get_comp(in_statement) + get_num(in_statement)

    ######
            if(in_statement.lower().find("cgpa")!=-1  or  in_statement.lower().find("cgpa marks")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and cgpa " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE cgpa " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("diploma")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and diploma " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE diploma " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("hsc")!=-1  or  in_statement.lower().find("12th")!=-1 or  in_statement.lower().find("twelfth")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and hsc " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE hsc " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("ssc")!=-1  or  in_statement.lower().find("10th")!=-1 or  in_statement.lower().find("xth")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and ssc " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE ssc " + get_comp(in_statement) + get_num(in_statement)

    ######

            if(in_statement.lower().find("branch")!=-1  or  in_statement.lower().find("department")!=-1 or  in_statement.lower().find("stream")!=-1 ):
                if(in_statement.lower().find("computer")!=-1  or  in_statement.lower().find("comp")!=-1 ):
                    if(and_q == 1):        
                        QUARY = QUARY + " and Branch = 'COMPUTER' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'COMPUTER' "
                    
                if(in_statement.lower().find("it")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'IT' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'IT' "

                if(in_statement.lower().find("mechanical")!=-1  or  in_statement.lower().find("mech")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'Mechanical' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'Mechanical' "

                if(in_statement.lower().find("e&tc")!=-1  or  in_statement.lower().find("electronics")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'E&TC' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'E&TC' "
            
                if(in_statement.lower().find("instru")!=-1  or  in_statement.lower().find("instrumentation")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'instrumentation' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'instrumentation' "
    ######

        elif(in_statement.lower().find("compani")!=-1  ):
            QUARY = 'SELECT COUNT (*) from company '        
            
            if(in_statement.lower().find("packag")!=-1  or  in_statement.lower().find("salari")!=-1 ):
               QUARY = QUARY + "WHERE Package " + get_comp(in_statement) +"'"+ get_num(in_statement)+"lac'"
            
            if(in_statement.lower().find("name")!=-1 or in_statement.lower().find("companynam")!=-1 ):
                if(in_statement.lower().find("microsoft")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Microsoft'" 
            
                if(in_statement.lower().find("amdoc")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Amdoc'" 

                if(in_statement.lower().find("tata")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'TATA motors'" 

                if(in_statement.lower().find("city")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Citi corp'" 

                if(in_statement.lower().find("baxter")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Baxter'" 

                if(in_statement.lower().find("honeywell")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Honeywell'" 


            if(in_statement.lower().find("job role")!=-1 or in_statement.lower().find("Job_Role")!=-1 ):
                if(in_statement.lower().find("developer")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Developer'" 

                if(in_statement.lower().find("software")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'SoftwareAssociator'" 

                if(in_statement.lower().find("graduate")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Graduate Tranee'" 

                if(in_statement.lower().find("research")!=-1 or in_statement.lower().find("r&d")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'R&D'" 

                if(in_statement.lower().find("tester")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Tester'" 

                if(in_statement.lower().find("automation")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Automation'" 


    ################################################################################################################################################
    ################################################################################################################################################
    ################################################################################################################################################



    if(in_statement.lower().find("delet")!=-1  or  in_statement.lower().find("remov")!=-1 ):
      
        if(in_statement.lower().find("students")!=-1  or  in_statement.lower().find("student")!=-1 ):
            QUARY = "DELETE FROM student "
            if(in_statement.lower().find("statu")!=-1  or  in_statement.lower().find("placed_status")!=-1 or  in_statement.lower().find("Status")!=-1 ):
                if(in_statement.lower().find("place")!=-1 or in_statement.lower().find("placed")!=-1):
                    if(and_q == 1):
                        QUARY = QUARY + " and Placed_status = 'YES' "
                    if(and_q == 0):
                        QUARY = QUARY + "WHERE Placed_status = 'YES' "
                        and_q = 1
                if(in_statement.lower().find("not_plac")!=-1 or in_statement.lower().find("not place")!=-1):
                    if(and_q == 1):
                        QUARY = QUARY + " and Placed_status = 'NO' "
                    if(and_q == 0):
                        QUARY = QUARY + "WHERE Placed_status = 'NO' "
                        and_q = 1
        
        
    ######
            if(in_statement.lower().find("roll")!=-1  or  in_statement.lower().find("roll_number")!=-1  or  in_statement.lower().find("roll_no")!=-1 ):
                if(and_q == 1):
                    QUARY = QUARY + " and roll_no " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE roll_no " + get_comp(in_statement) + get_num(in_statement)

    ######
            if(in_statement.lower().find("cgpa")!=-1  or  in_statement.lower().find("cgpa marks")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and cgpa " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE cgpa " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("diploma")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and Diploma " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE Diploma " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("hsc")!=-1  or  in_statement.lower().find("12th")!=-1 or  in_statement.lower().find("twelfth")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and hsc " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE hsc " + get_comp(in_statement) + get_num(in_statement)

            if(in_statement.lower().find("ssc")!=-1  or  in_statement.lower().find("10th")!=-1 or  in_statement.lower().find("xth")!=-1 ):
                if(and_q == 1):
                   QUARY = QUARY + " and ssc " + get_comp(in_statement) + get_num(in_statement)
                if(and_q == 0):
                    and_q = 1
                    QUARY = QUARY + "WHERE ssc " + get_comp(in_statement) + get_num(in_statement)

    ######

            if(in_statement.lower().find("branch")!=-1  or  in_statement.lower().find("department")!=-1 or  in_statement.lower().find("stream")!=-1 ):
                if(in_statement.lower().find("computer")!=-1  or  in_statement.lower().find("comp")!=-1 ):
                    if(and_q == 1):        
                        QUARY = QUARY + " and Branch = 'COMPUTER' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'COMPUTER' "
                    
                if(in_statement.lower().find("it")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'IT' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'IT' "

                if(in_statement.lower().find("mechanical")!=-1  or  in_statement.lower().find("mech")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'Mechanical' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'Mechanical' "

                if(in_statement.lower().find("entc")!=-1  or  in_statement.lower().find("electronics")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'E&TC' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'E&TC' "
            
                if(in_statement.lower().find("instru")!=-1  or  in_statement.lower().find("instrumentation")!=-1 ):
                    if(and_q == 1):
                        QUARY = QUARY + " and Branch = 'instrumentation' "
                    if(and_q == 0):
                        and_q = 1
                        QUARY = QUARY + "WHERE Branch = 'instrumentation' "
    ######

        elif(in_statement.lower().find("compani")!=-1  ):
            QUARY = 'DELETE FROM company '        
            
            if(in_statement.lower().find("packag")!=-1  or  in_statement.lower().find("salari")!=-1 ):
               QUARY = QUARY + "WHERE Package " + get_comp(in_statement) +"'"+ get_num(in_statement)
            
            if(in_statement.lower().find("name")!=-1 or in_statement.lower().find("companynam")!=-1 ):
                if(in_statement.lower().find("microsoft")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Microsoft'" 
            
                if(in_statement.lower().find("amdoc")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Amdoc'" 

                if(in_statement.lower().find("tata")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'TATA Motors'" 

                if(in_statement.lower().find("city")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Citi Corp'" 

                if(in_statement.lower().find("baxter")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Baxter'" 

                if(in_statement.lower().find("honeywell")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'Honeywell'"

                if(in_statement.lower().find("tcs")!=-1 ):    
                   QUARY = QUARY + "WHERE company_name = 'TCS'"


            if(in_statement.lower().find("job role")!=-1 or in_statement.lower().find("Job_Role")!=-1 ):
                if(in_statement.lower().find("developer")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Developer'" 

                if(in_statement.lower().find("software")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'SoftwareAssociator'" 

                if(in_statement.lower().find("graduate")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Graduate Tranee'" 

                if(in_statement.lower().find("research")!=-1 or in_statement.lower().find("r&d")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'R&D'" 

                if(in_statement.lower().find("tester")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Tester'" 

                if(in_statement.lower().find("automation")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Automation'"

                if(in_statement.lower().find("Associate software engineer")!=-1 ):    
                   QUARY = QUARY + "WHERE Job_Role = 'Associate Software Engineer'"


    print(QUARY)
    return QUARY



