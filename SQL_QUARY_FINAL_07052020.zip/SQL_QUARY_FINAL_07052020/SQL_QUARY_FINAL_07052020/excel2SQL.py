import mysql.connector

from mysql.connector import Error


import pandas as pd
from pandas import ExcelWriter
from pandas import ExcelFile


import tkinter as tk
from tkinter import filedialog
root = tk.Tk()
root.withdraw()

file_path = filedialog.askopenfilename()

df = pd.read_excel(file_path)

print("Column headings:")
print(df.columns)


mySQLconnection = mysql.connector.connect(host='localhost',
                        database='cummins',
                        user='root',
                        password='root')


mycursor = mySQLconnection.cursor()

print(df.index)

##for i in df.index:
##    sql = "INSERT INTO STUDENT (Sr,Roll,S_name,10th,12th,Diploma,CGPA,M_no,Placed,Branch) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
##
##    val = (str(df['Sr_no'][i]), str(df['Roll No.'][i]), str(df['Student Name'][i]), str(df['X th %'][i]), str(df['Xll th %'][i]),str(df['Diploma %'][i]), str(df['CGPA'][i]), str(df['Mobile Number'][i]), str(df['Placed_Status'][i]), str(df['Branch'][i]))
##
##    mycursor.execute(sql, val)
##    mySQLconnection.commit()



for i in df.index:
    sql = "INSERT INTO COMPANY (Sr,CompanyName,Location,Package,JobRole,Eligibility) VALUES (%s, %s, %s, %s, %s, %s)"

    val = (str(df['Sr.No'][i]), str(df['CompanyName'][i]), str(df['Location'][i]), str(df['Package'][i]), str(df['JobRole'][i]),str(df['Eligibility'][i]))

    mycursor.execute(sql, val)
    mySQLconnection.commit()







