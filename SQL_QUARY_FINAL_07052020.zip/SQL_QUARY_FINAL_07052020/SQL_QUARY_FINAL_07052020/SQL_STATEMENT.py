import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.corpus import wordnet

ps = PorterStemmer()

import SQL_statement_generation

def generate_SQL(example_sentence):

    print("Input Sentence ->")
    print(example_sentence)
    print(" ")
    stop_words = set(stopwords.words("english"))
    words = word_tokenize(example_sentence)


    filtered_sentence = [w for w in words if not w in stop_words]
    filtered_sentence =  ((' ').join(word for word in filtered_sentence))

    filtered_words = word_tokenize(filtered_sentence)
    stammer = []
    for w in filtered_words:
        stammer.append(ps.stem(w))

    stammer =  ((' ').join(word for word in stammer))
    #print (stammer)

    stammer_words = word_tokenize(stammer)
    #print(stammer_words)

    stam = [w for w in stammer_words if not w in '.']
    #print (stam)

    stam =  ((' ').join(word for word in stam))
    print("preprocessed_sentence ->")
    print (stam)
    print(" ")

    preprocessed_sentence = stam

    SQL_STATAMENT = SQL_statement_generation.get(preprocessed_sentence)

    print()
    return(SQL_STATAMENT)


