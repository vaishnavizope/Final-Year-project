import SQL_STATEMENT
import csv
import mysql.connector
from mysql.connector import Error
import time


def get(input_statement):

    quary = SQL_STATEMENT.generate_SQL(input_statement)


    file_name = input_statement.replace(' ','_') + '.csv'


    mydb = mysql.connector.connect(
         host="localhost",
         user="root",
         passwd="",
         database="cummins"
    )
    mycursor = mydb.cursor()
    try:    
        mycursor.execute(quary)
        mydb.commit()
    except:
        pass

    try:
        L = mycursor.fetchall()
        print('_________________________________________________________')
        print(L)
        print('_________________________________________________________')
        def check_get(sentence, test):
            for i in range (0,len(test)):
                get = 0
                sub_index = sentence.find(test[i])
                if sub_index != -1:
                    get = 1        
                    break
            return get


##        print("---------------------")
        company_csv = ['company']
        get_val = check_get(quary , company_csv)
        if(get_val == 1):
            print("COMPANY")
            with open(file_name, 'w', newline='') as csvfile:
                fieldnames = ['sr_no', 'company_name', 'Location', 'package', 'Job_role', 'eligibility']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

                writer.writeheader()
                for i in range (0,len(L)):
                    writer.writerow({'sr_no':L[i][0], 'company_name':L[i][1], 'Location':L[i][2], 'package':L[i][3], 'Job_role':L[i][4], 'eligibility':L[i][5] })


        else:
            print("STUDENT")
            with open(file_name, 'w', newline='') as csvfile:
                fieldnames = ['sr_no', 'roll_no', 'student_name', 'ssc', 'hsc', 'diploma', 'cgpa', 'Mobile_number', 'Placed_status', 'branch']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

                writer.writeheader()
                for i in range (0,len(L)):
                    writer.writerow({'sr_no':L[i][0], 'roll_no':L[i][1], 'student_name':L[i][2], 'ssc':L[i][3], 'hsc':L[i][4], 'diploma':L[i][5], 'cgpa':L[i][6], 'Mobile_number':L[i][7],'Placed_status':L[i][8] ,'branch':L[i][9] })


    except:
        print()
        print('___________')

    return quary, file_name

##
##in_statement = "list th student whose status equal to placed"
##
##a,b = get(in_statement)
##
##
##print('a :: ',a)
##print('b :: ',b)



