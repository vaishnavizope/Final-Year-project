def get_num(sentence):
    for word in sentence.split():
        try:
            num = float(word)
            break
        except ValueError:
            pass

    if(num%1 == 0):
        num = int(num)
        

    return ' ' + str(num)

def check_get(sentence, test):
    for i in range (0,len(test)):
        get = 0
        sub_index = sentence.find(test[i])
        if sub_index != -1:
            get = 1        
            break
    return get

def get_comp(sentence):

    GREATER = ['greater', 'great', 'higher', 'high', '>']
    SMALLER = ['smaller', 'small', 'lesser', 'less', '<']
    EQUAL = ['equal', 'exact', '=']
    CLUSTER_COMPARISION = [GREATER, SMALLER, EQUAL]
    SQL_QUARY = ''
    for i in range (0, len(CLUSTER_COMPARISION)):
        get_val = check_get(sentence,CLUSTER_COMPARISION[i])
        if(get_val == 1):
            if(i == 0):
                SQL_QUARY = SQL_QUARY + '>'
            if(i == 1):
                SQL_QUARY = SQL_QUARY + '<'
            if(i == 2):
                SQL_QUARY = SQL_QUARY + '='

    return  SQL_QUARY


