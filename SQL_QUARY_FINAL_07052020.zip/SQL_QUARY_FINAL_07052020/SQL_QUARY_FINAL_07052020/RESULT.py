from tkinter import *
from tkinter import messagebox
from tkinter.filedialog import askopenfilename
import tkinter as tk 
from tkinter import filedialog

import mysql.connector
from mysql.connector import Error
import time
import os

import speech_recognition as sr

import GET_SQL

import pandas as pd
from pandas import ExcelWriter
from pandas import ExcelFile


project_name = "SQL QUERY GENERATION"

from tkinter import Tk, Label, Entry, Toplevel, Canvas

from PIL import Image, ImageDraw, ImageTk, ImageFont
image = Image.open('SC.jpg')


########################################################################################    
def get():
    login_page = Tk()
    login_page.geometry("1300x600+30+30")
    login_page.configure(background="#ffff8f")
    global file_name
    file_name = ' '
    def LOGIN():


        def STATEMENT():
            global file_name
            input_statement = in_statement.get()

            quary, file_name = GET_SQL.get(input_statement)
            
            label2 = Label(login_page, text='Generated SQL Quary : ')
            label2.configure(background="#ffffFf")
            label2.config(font=("Courier", 12))
            label2.place(x = 750,y=350,height=20, width=500)

            label2 = Label(login_page, text=quary)
            label2.configure(background="#ffffFf")
            label2.config(font=("Times new roman", 12))
            label2.place(x = 650,y=390,height=20, width=700)



        def voice_in():
            print('voice')
            r = sr.Recognizer()
            with sr.Microphone() as source:
                r.adjust_for_ambient_noise(source, duration=5)
                print("Say something..!!")
                audio = r.listen(source,phrase_time_limit=10)
         
        # recognize speech using Google
            try:
                response = r.recognize_google(audio)
                print("You said '" + response + "'")
                in_statement.set(response)

                quary, file_name = GET_SQL.get(response)
                
                label2 = Label(login_page, text='Generated SQL Quary : ')
                label2.configure(background="#ffffFf")
                label2.config(font=("Courier", 12))
                label2.place(x = 750,y=350,height=20, width=500)

                label2 = Label(login_page, text=quary)
                label2.configure(background="#ffffFf")
                label2.config(font=("Courier", 14))
                label2.place(x = 750,y=390,height=20, width=500)

                
            except sr.UnknownValueError:
                print(">> Come again <<")
                in_statement.set("Come again")
                label2 = Label(login_page, text='Say it again')
                label2.configure(background="#ffffFf")
                label2.config(font=("Courier", 12))
                label2.place(x = 750,y=350,height=20, width=500)

                label2 = Label(login_page, text=" ")
                label2.configure(background="#ffffFf")
                label2.config(font=("Courier", 14))
                label2.place(x = 750,y=390,height=20, width=500)



        def view():
            global file_name
            os.system("start EXCEL.EXE "+  file_name)


        def add_file_students():
            root = Tk()
            root.withdraw()
            file_path = filedialog.askopenfilename()
            df = pd.read_excel(file_path)
            root.destroy()

            mydb = mysql.connector.connect(
                 host="localhost",
                 user="root",
                 passwd="",
                 database="cummins"
            )
            mycursor = mydb.cursor()

            mycursor.execute("SELECT * FROM student")
            L = mycursor.fetchall()

            try:
                df['Student Name'][1]
                valid = 1
            except:
                valid = 0
            
            if(valid == 1):
                for i in df.index:
                    found = 0
                    for x in range(0, len(L)):
                        if(L[x][2]== str(df['Student Name'][i]) ):
                            found = 1

                    if (found == 0):
                        sql = "INSERT INTO STUDENT (sr_no,roll_no,student_name,ssc,hsc,diploma,cgpa,mobile_number,placed_status,branch,status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                        val = (str(df['Sr_no'][i]), str(df['Roll No.'][i]), str(df['Student Name'][i]), str(df['X th %'][i]), str(df['Xll th %'][i]),str(df['Diploma %'][i]), str(df['CGPA'][i]), str(df['Mobile Number'][i]), str(df['Placed_Status'][i]), str(df['Branch'][i]), str(df['Status'][i]))
                        mycursor.execute(sql, val)
                        mydb.commit()

                label2 = Label(login_page, text="File Uploaded successfully")
                label2.configure(background="#ffffff",fg="#009900")
                label2.config(font=("Times new roman", 12))
                label2.place(x = 650,y=390,height=20, width=700)

            else:                
                label2 = Label(login_page, text="Please select proper file")
                label2.configure(background="#ffffff",fg="#cc0000")
                label2.config(font=("Times new roman", 12))
                label2.place(x = 650,y=390,height=20, width=700)
    
########

        def add_file_company():
            root = Tk()
            root.withdraw()
            file_path = filedialog.askopenfilename()
            df = pd.read_excel(file_path)
            root.destroy()

            mydb = mysql.connector.connect(
                 host="localhost",
                 user="root",
                 passwd="",
                 database="cummins"
            )
            mycursor = mydb.cursor()

            mycursor.execute("SELECT * FROM company")
            L = mycursor.fetchall()

            try:
                df['CompanyName'][1]
                valid = 1
            except:
                valid = 0
            
            if(valid == 1):
                for i in df.index:
                    found = 0
                    for x in range(0, len(L)):
                        if(L[x][1]== str(df['CompanyName'][i]) ):
                            found = 1
                    if (found == 0):
                        sql = "INSERT INTO COMPANY (sr_no,company_name,Location,package,Job_role,eligibility) VALUES (%s, %s, %s, %s, %s, %s)"
                        val = (str(df['Sr.No'][i]), str(df['CompanyName'][i]), str(df['Location'][i]), str(df['Package'][i]), str(df['JobRole'][i]),str(df['Eligibility'][i]))
                        mycursor.execute(sql, val)
                        mydb.commit()

                label2 = Label(login_page, text="File Uploaded successfully")
                label2.configure(background="#ffffff",fg="#009900")
                label2.config(font=("Times new roman", 12))
                label2.place(x = 650,y=390,height=20, width=700)

            else:                
                label2 = Label(login_page, text="Please select proper file")
                label2.configure(background="#ffffff",fg="#cc0000")
                label2.config(font=("Times new roman", 12))
                label2.place(x = 650,y=390,height=20, width=700)
    

########



        photoimage = ImageTk.PhotoImage(image)
        Label(login_page, image=photoimage).place(x=0,y=0)

        label2 = Label(login_page, text=project_name)
        label2.configure(background="#ffffFf")
        label2.config(font=("Courier", 30))
        label2.place(x = 150,y=20,height=40, width=1000)

        B1 = Button(login_page, text = "ENTER", command = STATEMENT)
        B1.place(x = 900,y = 260 ,height=35, width=200)
        B1.configure(background="#fffff0")


        B1 = Button(login_page, text = "Upload students sheet", command = add_file_students)
        B1.place(x = 750,y = 500 ,height=35, width=150)
        B1.configure(background="#fffff0")

        B1 = Button(login_page, text = "Upload company sheet", command = add_file_company)
        B1.place(x = 925,y = 500 ,height=35, width=150)
        B1.configure(background="#fffff0")

        B1 = Button(login_page, text = "View", command = view)
        B1.place(x = 1100,y = 500 ,height=35, width=150)
        B1.configure(background="#fffff0")


        in_statement = StringVar()
        bank1Entry = Entry(login_page, textvariable=in_statement)
        bank1Entry.configure(background="#ffffe0")
        bank1Entry.place(x =700,y=200,height=20, width=500)

        mm = Image.open('mic.png')
        MM = ImageTk.PhotoImage(mm)
        MIC = Button(image=MM, command=voice_in)
        MIC.place(x = 1225,y = 185 ,height=50, width=50)


        label2 = Label(login_page, text='  ')
        label2.configure(background="#ffffFf")
        label2.config(font=("Courier", 12))
        label2.place(x = 750,y=350,height=20, width=500)

        label2 = Label(login_page, text=' ')
        label2.configure(background="#ffffFf")
        label2.config(font=("Courier", 14))
        label2.place(x = 750,y=390,height=20, width=500)

        login_page.mainloop()

    LOGIN()

get()
